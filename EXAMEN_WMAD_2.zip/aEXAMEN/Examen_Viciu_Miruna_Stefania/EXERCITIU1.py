from bs4 import BeautifulSoup as bs
import requests
from pyquery import PyQuery as pq

headers = ({'User-Agent':
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36',
            'Accept-Language': 'en-US, en;q=0.5'})

urls = ['https://www.amazon.com/Rise-America-Remaking-World-Order/dp/154452143X/ref=zg_bsnr_books_73?_encoding=UTF8&psc=1&refRID=EPG8JM4TYA0BA8P1JQBY',
        'https://www.amazon.com/New-Case-Gold-James-Rickards/dp/1101980761/ref=pd_sbs_sccl_2_5/134-4877909-0346926?pd_rd_w=MribR&content-id=amzn1.sym.3676f086-9496-4fd7-8490-77cf7f43f846&pf_rd_p=3676f086-9496-4fd7-8490-77cf7f43f846&pf_rd_r=D3KHP20A8PV8XQDHVJP2&pd_rd_wg=ntNbL&pd_rd_r=083fed73-1cec-4e20-9e9c-2fc8da87e97e&pd_rd_i=1101980761&psc=1',
        'https://www.amazon.com/Aftermath-Secrets-Wealth-Preservation-Coming/dp/0735216959/ref=pd_bxgy_img_sccl_1/134-4877909-0346926?pd_rd_w=oD0dh&content-id=amzn1.sym.6b3eefea-7b16-43e9-bc45-2e332cbf99da&pf_rd_p=6b3eefea-7b16-43e9-bc45-2e332cbf99da&pf_rd_r=MK2TFY78KW7CB8CGYV9Z&pd_rd_wg=NJjN5&pd_rd_r=8fe68d1e-00f4-466a-a330-bba27b6b36cc&pd_rd_i=0735216959&psc=1',
        'https://www.amazon.com/Unsettled-Climate-Science-Doesnt-Matters/dp/1950665798/ref=zg_bsnr_books_76?_encoding=UTF8&psc=1&refRID=EPG8JM4TYA0BA8P1JQBY',
        'https://www.amazon.com/New-Great-Depression-Winners-Post-Pandemic/dp/0593330277/ref=pd_bxgy_img_sccl_1/134-4877909-0346926?pd_rd_w=64Er8&content-id=amzn1.sym.6b3eefea-7b16-43e9-bc45-2e332cbf99da&pf_rd_p=6b3eefea-7b16-43e9-bc45-2e332cbf99da&pf_rd_r=KZHX7CWAB2S9YD1Y4139&pd_rd_wg=hG0rR&pd_rd_r=a7e49a20-1f2e-4259-a617-fd408ee5fac6&pd_rd_i=0593330277&psc=1',
        'https://www.amazon.com/Tell-Bees-That-Gone-Outlander/dp/1101885688/ref=zg_bsnr_books_78?_encoding=UTF8&psc=1&refRID=EPG8JM4TYA0BA8P1JQBY',
        'https://www.amazon.com/Great-Devaluation-Embrace-Prepare-Monetary/dp/111969146X/ref=pd_sbs_sccl_2_6/134-4877909-0346926?pd_rd_w=cpcNC&content-id=amzn1.sym.3676f086-9496-4fd7-8490-77cf7f43f846&pf_rd_p=3676f086-9496-4fd7-8490-77cf7f43f846&pf_rd_r=QY072E6VC7AVGT0W0ESA&pd_rd_wg=L0vnI&pd_rd_r=af928e28-3ef1-456e-85b0-2250f03fcf54&pd_rd_i=111969146X&psc=1',
        'https://www.amazon.com/Juneteenth-Annette-Gordon-Reed/dp/1631498835/ref=zg_bsnr_books_80?_encoding=UTF8&psc=1&refRID=EPG8JM4TYA0BA8P1JQBY',
        'https://www.amazon.com/Newcomer-Novel-Mary-Kay-Andrews/dp/1250256968/ref=zg_bsnr_books_81?_encoding=UTF8&psc=1&refRID=EPG8JM4TYA0BA8P1JQBY',
        'https://www.amazon.com/Stamped-Kids-Racism-Antiracism-You/dp/0316167584/ref=zg_bsnr_books_82?_encoding=UTF8&psc=1&refRID=EPG8JM4TYA0BA8P1JQBY'
]

for url in urls:
    page = requests.get(url, headers=headers)
    soup = bs(page.text, 'html.parser')
    product_title = soup.find('span', {'id':'productTitle'}).text
    book_author = soup.find('a', {'class': 'a-link-normal contributorNameID'}).text
    year_extraction = soup.find('span', {'id': 'productSubtitle'}).text
    year = year_extraction[-5:]

    description = soup.find('div', {'id': 'bookDescription_feature_div'}).text

    # html = page.text
    # dom=pq(html)
    # second_review_number = dom('.count')

    second_review = soup.find('div',{'id':'editorialReviews_feature_div'}).text
    sec_rev_final = second_review.split('\n')[0]

    #print(second_review_number)

    print(f'\nTitle-------{product_title} Author-------{book_author}---------{year}')
    print(f'--- Description***********\n {description}\n**************************************')
    print(f'**************Second review**************\n{sec_rev_final}\n*******************************************************')
