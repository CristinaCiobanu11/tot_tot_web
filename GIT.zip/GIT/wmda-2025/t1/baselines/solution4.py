### **Exercise 4: Feature Engineering for Classification**
import pandas as pd
import seaborn as sns
from sklearn.preprocessing import MinMaxScaler

# Step 1: Load the Titanic dataset
df = sns.load_dataset("titanic")

