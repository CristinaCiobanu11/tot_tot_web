### **Exercise 1: Extracting and Cleaning Data from an API**
import requests
import pandas as pd

cities = ["New York", "London", "Tokyo", "Paris", "Berlin"]
#  url = f"https://wttr.in/{city}?format=%C+%t"
