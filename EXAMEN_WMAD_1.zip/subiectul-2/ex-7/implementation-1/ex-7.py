from scipy.stats import chisquare
import scipy.stats
from scipy.stats import chi2
from scipy.stats import chi2_contingency
import pandas as pd
import numpy as np
import os

filename = './bank-additional.csv'
dir_path = os.path.dirname(os.path.realpath(__file__))
file = os.path.join(dir_path, filename)
df_cmb_master = pd.read_csv(file, sep = ';')
df_cmb_master.shape
df_cmb_master.head()
df_cmb_master.dtypes
df_cmb_master.describe()
df_cmb_master.describe(include = 'object')
df_cmb_master['y'] = np.where(df_cmb_master['y'] == 'yes',1,0)
df_cmb_master['y'] = df_cmb_master['y'].astype(str)
df_cmb_master.isnull().sum()
col_list = list(df_cmb_master.columns)
col_list.remove('y')
for col in col_list:
    if df_cmb_master[[col]][col].dtype == 'object':
        df_cmb_master[[col]][col] = df_cmb_master[[col]][col].fillna((df_cmb_master[[col]][col].mode()))
    else:
        df_cmb_master[[col]][col] = df_cmb_master[[col]][col].fillna((df_cmb_master[[col]][col].mean()))

bins = [0, 1, 5, 10, 25, 50, 100]
df_cmb_master['age'] = pd.cut(df_cmb_master['age'], bins)

df_cmb_master['age'] = df_cmb_master.age.astype(str)
df_cmb_master['age'].unique()
df_cmb_master.head()

###Chisq Test for Independence
dataset_table=pd.crosstab(df_cmb_master['age'],df_cmb_master['y'])
#print(dataset_table)


#Observed Values
Observed_Values = dataset_table.values 
#print("Observed Values :-\n",Observed_Values)

val=chi2_contingency(dataset_table)
#val

Expected_Values=val[3]
#Expected_Values

chi_square=sum([(o-e)**2./e for o,e in zip(Observed_Values,Expected_Values)])
chi_square_statistic=chi_square[0]+chi_square[1]

no_of_rows=len(dataset_table.iloc[0:2,0])
no_of_columns=len(dataset_table.iloc[0,0:2])
ddof=(no_of_rows-1)*(no_of_columns-1)
#print("Degree of Freedom:-",ddof)
alpha = 0.05
#print("chi-square statistic:-",chi_square_statistic)
#scipy.stats.chi2.ppf() function

critical_value=scipy.stats.chi2.ppf(q=1-alpha,df=ddof)
#print('critical_value:',critical_value)

#p-value
p_value=1-chi2.cdf(x=chi_square_statistic,df=ddof)
print('p-value:',p_value)
print('Significance level: ',alpha)
print('Degree of Freedom: ',ddof)
print('p-value:',p_value)

df_cmb_master.dtypes
col_list = list(df_cmb_master.columns)
col_list.remove('y')
for col in col_list:
    if df_cmb_master[[col]][col].dtype == 'object':
        df_cmb_master[[col]][col] = df_cmb_master[[col]][col].fillna((df_cmb_master[[col]][col].mode()))
    else:
        df_cmb_master[[col]][col] = df_cmb_master[[col]][col].fillna((df_cmb_master[[col]][col].mean()))

col_list = list(df_cmb_master.columns)
col_list.remove('y')
for col in col_list:
    if df_cmb_master[[col]][col].dtype == 'object': 

        ###Chisq Test for Independence
        dataset_table=pd.crosstab(df_cmb_master[col],df_cmb_master['y'])
        #print(dataset_table)


        #Observed Values
        Observed_Values = dataset_table.values 
        #print("Observed Values :-\n",Observed_Values)

        val=chi2_contingency(dataset_table)
        #val

        Expected_Values=val[3]
        #Expected_Values

        chi_square=sum([(o-e)**2./e for o,e in zip(Observed_Values,Expected_Values)])
        chi_square_statistic=chi_square[0]+chi_square[1]

        no_of_rows=len(dataset_table.iloc[0:2,0])
        no_of_columns=len(dataset_table.iloc[0,0:2])
        ddof=(no_of_rows-1)*(no_of_columns-1)
        #print("Degree of Freedom:-",ddof)
        alpha = 0.05
        #print("chi-square statistic:-",chi_square_statistic)
        #scipy.stats.chi2.ppf() function

        critical_value=scipy.stats.chi2.ppf(q=1-alpha,df=ddof)
        #print('critical_value:',critical_value)

        #p-value
        p_value=1-chi2.cdf(x=chi_square_statistic,df=ddof)
        print(col)
        print('p-value:',p_value)
        #print('Significance level: ',alpha)
        #print('Degree of Freedom: ',ddof)
        #print('p-value:',p_value)
df_cmb_master.drop(columns = ['loan','day_of_week'],inplace = True)

def calculate_woe_iv(dataset, feature, target):
    lst = []
    for i in range(dataset[feature].nunique()):
        val = list(dataset[feature].unique())[i]
        lst.append({
            'Value': val,
            'All': dataset[dataset[feature] == val].count()[feature],
            'Good': dataset[(dataset[feature] == val) & (dataset[target] == 0)].count()[feature],
            'Bad': dataset[(dataset[feature] == val) & (dataset[target] == 1)].count()[feature]
        })
        
    dset = pd.DataFrame(lst)
    dset['Distr_Good'] = dset['Good'] / dset['Good'].sum()
    dset['Distr_Bad'] = dset['Bad'] / dset['Bad'].sum()
    dset['WoE'] = np.log(dset['Distr_Good'] / dset['Distr_Bad'])
    dset = dset.replace({'WoE': {np.inf: 0, -np.inf: 0}})
    dset['IV'] = (dset['Distr_Good'] - dset['Distr_Bad']) * dset['WoE']
    iv = dset['IV'].sum()
    
    dset = dset.sort_values(by='WoE')
    
    return dset, iv

df_cmb_master['y'] = df_cmb_master['y'].astype(int)
col_list = list(df_cmb_master.columns)
#col_list = ['age']
for col in col_list:
    if col == 'y': 
        continue
    elif df_cmb_master[col].dtype == 'object':
        print('IV for column: {}'.format(col))
        df, iv = calculate_woe_iv(df_cmb_master, col, 'y')
        #print(df)
        print('IV score: {:.2f}'.format(iv))
        print('\n')

df_cmb_master.drop(columns = ['age', 'marital', 'education', 'housing'],inplace = True)
df_cmb_master.columns
df_cmb_master.dtypes

col_list = []
for col in df_cmb_master.columns:
    if ((df_cmb_master[col].dtype == 'object') & (col != 'y') ):
        col_list.append(col)

# df = pd.DataFrame({'name': ['Manie', 'Joyce', 'Ami'],
#                    'Org':  ['ABC2', 'ABC1', 'NSV2'],
#                    'Dept': ['Finance', 'HR', 'HR']        
#         })


df_2 = pd.get_dummies(df_cmb_master[col_list],drop_first=True)

for col in df_2.columns:
    df_2[col] =  df_2[col].astype(int)
df_2.shape

df_combined = pd.concat([df_cmb_master, df_2], axis=1)
df_combined.shape

col_list = []
for col in df_cmb_master.columns:
    if ((df_cmb_master[col].dtype == 'object') & (col != 'y') ):
        col_list.append(col)

df_combined.drop(columns = col_list,axis = 1,inplace = True)
df_combined.dtypes

from statsmodels.stats.outliers_influence import variance_inflation_factor 
col_list = []
for col in df_combined.columns:
    if ((df_combined[col].dtype != 'object') & (col != 'y') ):
        col_list.append(col)

X = df_combined[col_list]
vif_data = pd.DataFrame() 
vif_data["feature"] = X.columns 
vif_data["VIF"] = [variance_inflation_factor(X.values, i) 
                          for i in range(len(X.columns))] 
print(vif_data)

df_combined.columns

Ind_Features = list(df_combined.columns)
Ind_Features.remove('y')
df_ind = df_combined[Ind_Features]
df_dep = df_combined['y']

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(df_ind, df_dep, test_size=0.25, random_state=0)

x_train.shape
x_test.shape

from sklearn.linear_model import LogisticRegression
logisticRegr = LogisticRegression()

x_train
logisticRegr.fit(x_train, y_train)

test_pred = logisticRegr.predict(x_test)
np.unique(test_pred)
x_test.shape
test_pred.shape
test_pred

import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import metrics

cm = metrics.confusion_matrix(y_test, test_pred)
print(cm)
Accuracy =  (8909+429)/(8909+429+729+230)
Accuracy*100
Sensitivity = 429/(429 + 729 )
Sensitivity*100
Specifiicty = 8909/(8909 + 230 )
Specifiicty*100

score = logisticRegr.score(x_test, y_test)
print(score)

test_pred_prob = logisticRegr.predict_proba(x_test)
test_pred_prob

test_pred_prob[:, 1]
test_pred
np.array(y_test)

from sklearn import metrics
y = np.array([1, 1, 2, 2])
scores = np.array([0.1, 0.4, 0.35, 0.8])
fpr, tpr, thresholds = metrics.roc_curve(np.array(y_test), test_pred_prob[:, 1], pos_label=1)

auc_table = pd.DataFrame(fpr)
auc_table['tpr'] = tpr
auc_table['thresholds'] = thresholds

auc_table.columns = ['fpr','tpr','thresholds']
auc_table.head()

from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_curve
from sklearn.metrics import roc_auc_score
from matplotlib import pyplot

# calculate scores
auc = roc_auc_score(np.array(y_test), test_pred_prob[:, 1])

# summarize scores

print('Logistic: ROC AUC=%.3f' % (auc))

# calculate roc curves

fpr, tpr, _ = roc_curve(np.array(y_test), test_pred_prob[:, 1])
# plot the roc curve for the model

pyplot.plot(fpr, tpr, marker='.', label='Logistic')
# axis labels
pyplot.xlabel('False Positive Rate')
pyplot.ylabel('True Positive Rate')
# show the legend
pyplot.legend()
# show the plot
pyplot.show()