  
# -*- coding: utf-8 -*-
import numpy as np 
import pandas as pd
import warnings
warnings.simplefilter("ignore")
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import os
plt.style.use('ggplot')
# %matplotlib inline

filename = './mushrooms.csv'
dir_path = os.path.dirname(os.path.realpath(__file__))
file = os.path.join(dir_path, filename)

dataset=pd.read_csv(file)
dataset.head()

dataset.isnull().sum()

dataset.describe(  
)

X=dataset.drop('class',axis=1) #Predictors
y=dataset['class'] #Response
X.head()

from sklearn.preprocessing import LabelEncoder
Encoder_X = LabelEncoder() 
for col in X.columns:
    X[col] = Encoder_X.fit_transform(X[col])
Encoder_y=LabelEncoder()
y = Encoder_y.fit_transform(y)

X.head()

grp = X.groupby('habitat')
x = grp['odor'].agg(np.mean)
p = grp['population'].agg(np.sum)
z = grp['bruises'].agg(np.mean)
print(x)
print(y)
print(z)

plt.figure(figsize=(12,5))
plt.plot(x, "ro", color='g')
plt.xticks(rotation=90)
plt.xlabel('Habitat-->')
plt.ylabel('Odor-->')
plt.show()

plt.figure(figsize=(16,5))
plt.plot(p,'r--', color='b')
plt.xticks(rotation=90)
plt.xlabel('Habitat-->')
plt.ylabel('Population-->')
plt.show()

plt.figure(figsize=(16,5))
plt.plot(z,'bs', color='g')
plt.xticks(rotation=90)
plt.xlabel('Habitat-->')
plt.ylabel('Bruises-->')
plt.show()

from sklearn.preprocessing import LabelEncoder
Encoder_X = LabelEncoder() 
for col in X.columns:
    X[col] = Encoder_X.fit_transform(X[col])
Encoder_y=LabelEncoder()
y = Encoder_y.fit_transform(y)
X.head()

X=pd.get_dummies(X,columns=X.columns,drop_first=True)
X.head()

X.shape

y.shape

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

#standardization of the data

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()

X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)

from sklearn.decomposition import PCA
pca = PCA(n_components=2)

X_train = pca.fit_transform(X_train)
X_test = pca.transform(X_test)

from sklearn.model_selection import cross_val_predict, cross_val_score
from sklearn.metrics import confusion_matrix,classification_report,accuracy_score

def print_score(classifier,X_train,y_train,X_test,y_test,train=True):
    if train == True:
        print("Training results:\n")
        print('Accuracy Score: {0:.4f}\n'.format(accuracy_score(y_train,classifier.predict(X_train))))
        print('Classification Report:\n{}\n'.format(classification_report(y_train,classifier.predict(X_train))))
        print('Confusion Matrix:\n{}\n'.format(confusion_matrix(y_train,classifier.predict(X_train))))
        res = cross_val_score(classifier, X_train, y_train, cv=10, n_jobs=-1, scoring='accuracy')
        print('Average Accuracy:\t{0:.4f}\n'.format(res.mean()))
        print('Standard Deviation:\t{0:.4f}'.format(res.std()))
    elif train == False:
        print("Test results:\n")
        print('Accuracy Score: {0:.4f}\n'.format(accuracy_score(y_test,classifier.predict(X_test))))
        print('Classification Report:\n{}\n'.format(classification_report(y_test,classifier.predict(X_test))))
        print('Confusion Matrix:\n{}\n'.format(confusion_matrix(y_test,classifier.predict(X_test))))

from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression()

classifier.fit(X_train,y_train)

print_score(classifier,X_train,y_train,X_test,y_test,train=True)

print_score(classifier,X_train,y_train,X_test,y_test,train=False)

from sklearn.naive_bayes import GaussianNB
m = GaussianNB()
m.fit(X_train, y_train)

#y_pred = m.predict(X_test)

print_score(m,X_train,y_train,X_test,y_test,train=True)

print_score(classifier,X_train,y_train,X_test,y_test,train=False)