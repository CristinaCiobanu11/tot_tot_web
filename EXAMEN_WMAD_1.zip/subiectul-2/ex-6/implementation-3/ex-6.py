import os
import pandas as pd
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report,confusion_matrix
from sklearn.ensemble import RandomForestClassifier

cols = ['class','cap_shape','cap_surface','cap_color','bruises_?','odour','gill_attachment',
        'gill_spacing','gill_size','gill_color','stalk_shape','stalk_root','stalk_surface_above_ring',
        'stalk_surface_below_ring','stalk_color_above_ring','stalk_color_below_ring','veil_type', 
        'veil_color','ring_number','ring_type','spore_print_color','population','habitat']

filename = './agaricus-lepiota.data'
dir_path = os.path.dirname(os.path.realpath(__file__))
file = os.path.join(dir_path, filename)

df = pd.read_csv(file, names=cols)
#inspecting first 3 rows
df.iloc[0:3]
df.info()
le =  LabelEncoder()

# Iterate over all the values of each column and extract their dtypes
for col in df:
    if df[col].dtype=='object':
    # Use LabelEncoder to do the numeric transformation
        df[col]=le.fit_transform(df[col])

df.dtypes
print(set(df['class']))
df.groupby(['class']).size() / df.shape[0] * 100
y = df['class']
# define X as anything BUT target variable
X_cols = [col for col in df.columns if col not in 'class']
X = df[X_cols]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1)
dtree = DecisionTreeClassifier()
dtree.fit(X_train, y_train)
predictions = dtree.predict(X_test)
print(classification_report(y_test,predictions))
print(confusion_matrix(y_test,predictions))


rfc = RandomForestClassifier(n_estimators=100)
rfc.fit(X_train, y_train)
rfc_pred = rfc.predict(X_test)
print(confusion_matrix(y_test,rfc_pred))