import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from sklearn.tree import DecisionTreeClassifier, plot_tree
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import chi2
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.metrics import classification_report
from sklearn.metrics import confusion_matrix
import os

filename = './agaricus-lepiota.data'
dir_path = os.path.dirname(os.path.realpath(__file__))
file = os.path.join(dir_path, filename)

agaricus_lepiota = pd.read_csv(file)
agaricus_lepiota.info()
agaricus_lepiota.head()

agaricus_lepiota.rename(columns={'p':'classes','x':"cap-shape",'s':"Cap-surface",'n':"cap-color",
't':"bruises?",'p.1':"odor", 'f':"gill-attachment",'c':"gill-spacing",'n.1':"gill-size",'k':"gill-color",
'e':"stalk-shape", 'e.1':"stalk-root", 's.1':"stalk-surface-above-ring",'s.2':"stalk-surface-below-ring",
 'w':"stalk-color-above-ring", 'w.1':"stalk-color-below-ring",'p.2':"veil-type",'w.2':"veil-color",'o':"ring-number",'p.3':"ring-type",'k.1':"spore-print-color",'s.3':"population",'u':"habitat"}, inplace=True)

for col in agaricus_lepiota.columns:
    print(agaricus_lepiota[col].value_counts())

agaricus_lepiota.drop(['stalk-root','veil-type'], axis=1,inplace=True)
agaricus_lepiota.isnull().values.sum()
agaricus_lepiota.describe()
agaricus_lepiota.classes = agaricus_lepiota.classes.map({'e':1,'p':0})

le = LabelEncoder()
for col in agaricus_lepiota:
    # Compare if the dtype is object
    if agaricus_lepiota[col].dtypes=='object':
    # Use LabelEncoder to do the numeric transformation
        agaricus_lepiota[col]=le.fit_transform(agaricus_lepiota[col])

fig, ax = plt.subplots(figsize=(15,15)) 
sns.heatmap(agaricus_lepiota.corr() , annot=True)
plt.show()
X = agaricus_lepiota.iloc[:,1:]  #independent columns
y = agaricus_lepiota.iloc[:,0]    #target column i.e price range
#apply SelectKBest class to extract top 10 best features
bestfeatures = SelectKBest(score_func=chi2, k=10)
fit = bestfeatures.fit(X,y)
dfscores = pd.DataFrame(fit.scores_)
dfcolumns = pd.DataFrame(X.columns)
#concat two dataframes for better visualization 
featureScores = pd.concat([dfcolumns,dfscores],axis=1)
featureScores.columns = ['columns','Score']  #naming the dataframe columns
print(featureScores.nlargest(10,'Score'))  #print 10 best features
model = ExtraTreesClassifier()
model.fit(X,y)
feat_importances = pd.Series(model.feature_importances_, index=X.columns)
feat_importances.nlargest(10).plot(kind='barh')
plt.show()
# selecting best 10 features
x=agaricus_lepiota[['gill-color','ring-type','gill-size','bruises?','stalk-shape','gill-spacing','habitat','spore-print-color','population','stalk-surface-above-ring' ]]
# getting dummies for the selected features 
X =pd.get_dummies(x, drop_first=True)
y = agaricus_lepiota.classes
# spliting data set to train and test set
X_train, X_test, y_train, y_test= train_test_split(X, y,
test_size=0.3,
stratify=y,
random_state=42)
seed=42
dt = DecisionTreeClassifier(random_state=seed)
from sklearn.model_selection import GridSearchCV
# Define the grid of hyperparameters 'params_dt'
params_dt = {
'max_depth': [3, 4,5, 6],
'min_samples_leaf': [0.04, 0.06, 0.08],
'max_features': [0.2, 0.4,0.6, 0.8]
}
# Instantiate a 10-fold CV grid search object 'grid_dt'
grid_dt = GridSearchCV(estimator=dt,
param_grid=params_dt,
scoring=
'accuracy'
,
cv=10,
n_jobs=-1)
# Fit 'grid_dt' to the training data
grid_dt.fit(X_train, y_train)

# Extract best hyperparameters from 'grid_dt'
best_hyperparams = grid_dt.best_params_
print('Best hyerparameters:\n'
, best_hyperparams, ':\n')

# Extract best CV score from 'grid_dt'
best_CV_score = grid_dt.best_score_
print('Best CV accuracy',best_CV_score)

# Extract best model from 'grid_dt'
best_model = grid_dt.best_estimator_
# Evaluate test set accuracy
test_acc = best_model.score(X_test,y_test)
# Print test set accuracy
print("Test set accuracy of best model:",test_acc)

dt = DecisionTreeClassifier(max_depth=3, max_features=0.6, min_samples_leaf=0.04, random_state=seed)
dt.fit(X_train, y_train)

y_pred = dt.predict(X_test)
accuracy_score(y_pred,y_test)

ytrain_pred = dt.predict(X_train) 
accuracy_score(ytrain_pred,y_train)

print('test')
print(classification_report(y_test,y_pred))
print('train')
print(classification_report(y_train,ytrain_pred))


# Print the confusion matrix of the decision tree model
print("test_set")
print(confusion_matrix(y_test, y_pred))
print("train_set")
print(confusion_matrix(y_train, ytrain_pred))
pos = 1144 + 103
total = confusion_matrix(y_test,y_pred).sum()
prevalence=(pos/total)*100
posi = 2663 + 233
Sum = confusion_matrix(y_train,ytrain_pred).sum()
prev=(posi/Sum)*100
print("testset prevalence",prevalence)
print("trainset prevalence",prev)

print("Sensitivity", 1144/(1144+103))
print("Specificity",1159/(1159+31))
plot_tree(dt)