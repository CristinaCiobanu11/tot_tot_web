import os
import numpy as np  # linear algebra
import pandas as pd  # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt  # data visualization
from sklearn import preprocessing
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
import seaborn as sns
from sklearn.preprocessing import LabelEncoder

dir_path = os.path.dirname(os.path.realpath(__file__))
information_csv = './information.csv'
info = os.path.join(dir_path, information_csv)
test_csv = './test.csv'
test = os.path.join(dir_path, test_csv)
train_csv = './training.csv'
train = os.path.join(dir_path, train_csv)

info_df = pd.read_csv(info)
test_df = pd.read_csv(test)
train_df = pd.read_csv(train)

print(train_df.head())

# drop la coloanele fara valori 'NaN'
train_df.drop(['Unnamed: 6', 'Unnamed: 7', 'Attribute Information:'], axis=1, inplace=True)
train_df.rename(columns={' UNS': 'Knowledge Level'}, inplace=True)
print(train_df.head())


def fix_data(temp_df):
    temp_df.drop(['Unnamed: 6', 'Unnamed: 7', 'Attribute Information:'], axis=1, inplace=True)
    temp_df.rename(columns={' UNS': 'Knowledge Level'}, inplace=True)
    return temp_df


test_df = fix_data(test_df)
print(test_df.head())

# Checking data for nan values
'''
As above we need to do all operation twice for both of the data frames so we will design a function.
'''


def clean_my_data(_df):
    if _df.isnull().values.any():  # isnull().values.any() returns a boolean value depending upon the presence of null value anywhere in data
        print(_df.isnull())  # returns dataframe filled with boolean values for presence of null
        _df = _df.dropna()
    else:
        print('Your data do not contain any missing values.')
    return _df


train_df = clean_my_data(train_df)
test_df = clean_my_data(test_df)


def label_encode_categorical_data(data):
    encoder = LabelEncoder()
    encoded_column = encoder.fit_transform(data['Knowledge Level'])
    data['Knowledge Level'] = encoded_column
    return data


train_df = label_encode_categorical_data(train_df)
print(train_df.head())

sns.pairplot(train_df[train_df.select_dtypes(include=[np.number]).columns])
f, ax = plt.subplots(figsize=(10, 6))
sns.boxplot(data=train_df, x='Knowledge Level', y='PEG', ax=ax)

train_df.drop(train_df[train_df['PEG'] < 0].index, axis=1, inplace=True)
train_df.boxplot(layout=(2, 3), by='Knowledge Level', figsize=[15, 10])

f, ax = plt.subplots(figsize=(10, 4))
sns.countplot(x='Knowledge Level', data=train_df, palette="Set2", ax=ax)
plt.grid(True)

f, ax = plt.subplots(figsize=(10, 8))
sns.heatmap(train_df.corr(), annot=True, linewidths=.5, fmt='.2f', ax=ax)

# f, ax = plt.subplots(figsize=(10, 8))
# sns.scatterplot(train_df['STG'], hue=train_df['Knowledge Level'], ax=ax, palette="Set1")
# ax.set_facecolor('#e0f2fc')
# plt.grid(True)

f, ax = plt.subplots(figsize=(10, 8))
sns.scatterplot(train_df, x='SCG', y='STG', hue='Knowledge Level', ax=ax, palette="Set1")
ax.set_facecolor('#e0f2fc')
plt.grid(True)

# f, ax = plt.subplots(figsize=(10, 8))
# sns.scatterplot(train_df['PEG'], hue=train_df['Knowledge Level'], ax=ax, palette="Set1")
# ax.set_facecolor('#e0f2fc')
# plt.grid(True)

Knowledge_levels = train_df['Knowledge Level'].unique()

df = train_df
# label_encoder object knows how to understand word labels. 
label_encoder = preprocessing.LabelEncoder()

# Encode labels in column 'species'. 
df['Knowledge Level'] = label_encoder.fit_transform(df['Knowledge Level'])
test_df['Knowledge Level'] = label_encoder.fit_transform(test_df['Knowledge Level'])


print('Encoding Approach:')
for i, j in zip(Knowledge_levels, df['Knowledge Level'].unique()):
    print('{}  ==>  {}'.format(i, j))

df = df._append(test_df, ignore_index=True)  # using append to add two datasets.

X = df.drop(['Knowledge Level'], axis=1)  # assigning X all the independent variable
y = df['Knowledge Level']  # assigning y the target variable

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1)  # using train_test_split() to randomly split dataset to train and test.

# In actual we will be using Support Vector Classifier thats why we create an object of SVC.
clf = SVC()
clf.fit(X_train, y_train)  # fitting data in the model.
clf.score(X_test, y_test)
