import os
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

import scipy.cluster.hierarchy as shc
from sklearn.cluster import KMeans

data = './data.csv'
dir_path = os.path.dirname(os.path.realpath(__file__))
file = os.path.join(dir_path, data)

users = pd.read_csv(file, delimiter=',')
print(users.head())
print(f'\n{users.shape}')
print(f'\n{users.dtypes}')
print(f'\n{users.isna().sum()}')
print(f'\n{users.duplicated().sum()}')
print(f'\n{users.describe()}')

# Exploratory data
plt.figure(1, figsize=(15, 4))
pal1 = ["#FA5858", "#58D3F7", "#704041", "#f5c3c4"]
sns.countplot(y=' UNS', data=users, palette=pal1)
plt.show()  # display figure 1

sns.set(style="ticks")
pal = ["#FA5858", "#58D3F7", "#adf2f1", "#704041"]
sns.pairplot(users, hue=" UNS", palette=pal)
plt.title(" UNS")
plt.show()  # display figure 2

X = users[['STG', 'PEG']].iloc[:, :].values
inertia = []
for n in range(1, 10):
    models = (KMeans(n_clusters=n, init='k-means++', n_init=10, max_iter=100,
                     tol=0.0001, random_state=100))
    models.fit(X)
    inertia.append(models.inertia_)

# plt.figure(1, figsize=(15, 6))
plt.plot(range(1, 10), inertia)
# plt.plot(range(1, 10), inertia, '-', alpha=0.5)
plt.xlabel('Number of Clusters')
plt.ylabel('Inertia')
plt.show()

models = (KMeans(n_clusters=3, init='k-means++', n_init=10, max_iter=300,
                 tol=0.0001, random_state=111))
models.fit(X)
labels = models.labels_
centroids = models.cluster_centers_
print(models.cluster_centers_)
print(models.inertia_)
print(models.n_iter_)

# fig = plt.figure(figsize=(12,8))

# plt.scatter(X[:,0], X[:,1], c=models.labels_, cmap="Set1_r", s=25)
# plt.scatter(models.cluster_centers_[:,0] ,models.cluster_centers_[:,1], color='blue', marker="*", s=250)
# plt.title("Kmeans Clustering \n Finding Unknown Groups in the Population", fontsize=16)
# plt.show()

# models2 = (KMeans(n_clusters = 4 ,init='k-means++', n_init = 10 ,max_iter=300, 
#                         tol=0.0001,  random_state= 111  , algorithm='elkan') )
# models2.fit(X)
# labels2 = models2.labels_
# centroids2 = models2.cluster_centers_
# print(models2.cluster_centers_)

# print(models2.inertia_)
# print(models2.n_iter_)

# fig = plt.figure(figsize=(12,8))
# plt.scatter(X[:,0], X[:,1], c=models2.labels_, cmap="Set1_r", s=25)
# plt.scatter(models2.cluster_centers_[:,0] ,models2.cluster_centers_[:,1], color='blue', marker="*", s=250)
# plt.title("Kmeans Clustering \n Finding Unknown Groups in the Population", fontsize=16)
# plt.show()

X = users[['STG', 'SCG', 'STR', 'LPR', 'PEG']].iloc[:, :].values
plt.figure(figsize=(10, 7))
plt.title("User Knowledge Dendograms")
plt.xlabel('Users')
dendrogram = shc.dendrogram(shc.linkage(X, method='complete'))
plt.show()  # last figure display
