from bs4 import BeautifulSoup as bs
import requests

headers = ({'User-Agent':
                'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
            'Accept-Language': 'en-US, en;q=0.5'})

urls = ['https://www.metacritic.com/movie/titanic',
        'https://www.metacritic.com/movie/the-blind-man-who-did-not-want-to-see-titanic',
        'https://www.metacritic.com/movie/pitch-perfect',
        'https://www.metacritic.com/movie/the-mustang',
        'https://www.metacritic.com/movie/the-pianist',
        'https://www.metacritic.com/movie/the-last-samurai',
        'https://www.metacritic.com/movie/flower',
        'https://www.metacritic.com/movie/summer-1993',
        'https://www.metacritic.com/movie/the-dark-knight',
        'https://www.metacritic.com/movie/a-man-called-otto']

for url in urls:
    page = requests.get(url, headers=headers)
    soup = bs(page.text, 'lxml')
    director = soup.find('div', attrs={'class': 'director'}).find('a').find('span').text
    print(director)
    score_critics = soup.find('a', attrs={'class': 'metascore_anchor'}).find('span').text
    print(score_critics)
    score_users = soup.find('div', attrs={'class': 'user_score_summary'}).find('a', attrs={'class': 'metascore_anchor'}).find('span').text
    print(score_users)
    runtime = soup.find('div', attrs={'class': 'runtime'}).find_next('span').find_next('span').text
    print(runtime)
