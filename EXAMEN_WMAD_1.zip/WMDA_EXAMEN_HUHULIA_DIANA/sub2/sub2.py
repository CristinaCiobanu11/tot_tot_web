from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, ConfusionMatrixDisplay
from sklearn.preprocessing import StandardScaler


path = Path.cwd() / 'house-votes-84.csv'
house_votes = pd.read_csv(path)

coloane = [' handicapped-infants', ' water-project-cost-sharing', ' adoption-of-the-budget-resolution', ' physician-fee-freeze',
            ' el-salvador-aid', ' religious-groups-in-schools', ' anti-satellite-test-ban', ' aid-to-nicaraguan-contras',
            ' mx-missile', ' immigration', ' synfuels-corporation-cutback', ' education-spending', ' superfund-right-to-sue',
            ' crime', ' duty-free-exports', ' export-administration-act-south-africa']

for coloana in coloane:
    house_votes[coloana] = house_votes[coloana].replace('?', 0.5)
    house_votes[coloana] = house_votes[coloana].replace('y', 1)
    house_votes[coloana] = house_votes[coloana].replace('n', 0)

house_votes['Class Name'] = house_votes['Class Name'].replace('democrat', 0)
house_votes['Class Name'] = house_votes['Class Name'].replace('republican', 1)

plt.figure(figsize=(18, 9))
sns.heatmap(house_votes.corr(), annot=True, cmap="YlGnBu")
plt.show()

X = house_votes.drop(columns=['Class Name'], axis=1)
y = house_votes['Class Name']
train_pct_index = int(0.9 * len(X))
X_train, X_test = X[:train_pct_index], X[train_pct_index:]
y_train, y_test = y[:train_pct_index], y[train_pct_index:]

scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

rdf_model = RandomForestClassifier(n_estimators=100)
rdf_fit = rdf_model.fit(X_train, y_train)
rdf_predictions = rdf_model.predict(X_test)

confusion_matrix_rf = confusion_matrix(y_test, rdf_predictions.round())
print(confusion_matrix_rf)

ConfusionMatrixDisplay.from_estimator(rdf_fit, X_test, y_test)
plt.show()

print(f"Accuracy: {accuracy_score(y_test, rdf_predictions.round()):.5f}")

