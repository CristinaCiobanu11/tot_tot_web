import requests
from bs4 import BeautifulSoup
headers = ({'User-Agent':
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
            'Accept-Language': 'en-US, en;q=0.5'})

url='https://www.amazon.com/EVGA-White-Warranty-Supply-100-W3-0600-K1/dp/B08WYHVCRP/ref=sr_1_1_sspa?dchild=1&qid=1621877523&s=computers-intl-ship&sr=1-1-spons&psc=1&spLa=ZW5jcnlwdGVkUXVhbGlmaWVyPUFLVTEwVDdKWENBQ0wmZW5jcnlwdGVkSWQ9QTEwMDk3MjIyWlo2TTFDM09ZUzQyJmVuY3J5cHRlZEFkSWQ9QTA1ODI2MDkyVElOT0VLNTE2TFM3JndpZGdldE5hbWU9c3BfYXRmX2Jyb3dzZSZhY3Rpb249Y2xpY2tSZWRpcmVjdCZkb05vdExvZ0NsaWNrPXRydWU='
page = requests.get(url,headers=headers)
soup = BeautifulSoup(page.content, "lxml")
product_name = soup.find(id="productTitle").text.strip()
product_price=soup.find(class_="a-offscreen").text
product_description=soup.find(id="productDescription").text.strip()
# s1=soup.find("div",attrs={'id':'ask-btf_feature_div'})
# s2=soup.find("li",attrs={'class':'label'})
print(f'{product_name}, is priced at {product_price},{product_description}, the second review was times upvoted')
