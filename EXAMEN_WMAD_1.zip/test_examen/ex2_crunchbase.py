import requests
from bs4 import BeautifulSoup
headers = ({'User-Agent':
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36',
            'Accept-Language': 'en-US, en;q=0.5'})
url='https://www.crunchbase.com/organization/twitter'
page = requests.get(url,headers=headers)
soup = BeautifulSoup(page.content, "lxml")
# location= soup.find("a",attrs={'title':'San Francisco'}).text.strip()\
#           +", "+soup.find("a",attrs={'title':'California'}).text.strip()\
#           +", "+soup.find("a",attrs={'title':'United States'}).text.strip()
# print(f'{location}')

parent=soup.find('span',attrs={'class':'component--field-formatter field-type-identifier-multi'})
locations=parent.find_all("a",attrs={'class':'link-accent ng-star-inserted'})
for loc in locations:
    print(loc.text.strip())
number_employees=soup.find("a",attrs={'class':'component--field-formatter field-type-enum link-accent ng-star-inserted'}).text.strip()
print(number_employees)

website=soup.find("a",attrs={'title':"www.twitter.com"}).text.strip()
print(website)
funding_amount=soup.find("span",attrs={'title':"$12.9B"}).text.strip()
print(funding_amount)