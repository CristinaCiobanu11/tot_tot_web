
# Se da setul de date: http://archive.ics.uci.edu/ml/datasets/Bank+Marketing#. Sa se
# antreneze un mecanism care sa prezica dacă un client va face un depozit pe termen lung.
# # Ultimele 10% dintre randuri vor fi utilizate ca exemple de test.

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

bank_data = pd.read_csv("bank.csv", sep=';')


print(bank_data.head())

# 2. Pregătirea datelor
# Convertim variabilele categorice în variabile numerice folosind one-hot encoding
bank_data = pd.get_dummies(bank_data, drop_first=True)

# Definim caracteristicile (X) și variabila de clasă (y)
X = bank_data.drop('y_yes', axis=1)  # Caracteristicile
y = bank_data['y_yes']  # Variabila de clasă

# 3. Divizarea datelor
split_index = int(len(bank_data) * 0.9)


X_train, X_test = X[:split_index], X[split_index:]
y_train, y_test = y[:split_index], y[split_index:]


rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)


y_pred = rf_model.predict(X_test)
print("PREDICTED")
print(y_pred)
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

