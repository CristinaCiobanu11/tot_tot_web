# Se dă setul de date: https://archive.ics.uci.edu/dataset/53/iris .
# Să se aplice un algoritm de clustering și să se afișeze care intrare aparține cărui cluster.

import pandas as pd
from sklearn.cluster import KMeans
import matplotlib.pyplot as plt


url = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"
column_names = ['sepal_length', 'sepal_width', 'petal_length', 'petal_width', 'class']
df = pd.read_csv(url, header=None, names=column_names)

print(df.head())

X = df.drop(columns=['class'])

kmeans = KMeans(n_clusters=3, random_state=42)
kmeans.fit(X)


df['cluster'] = kmeans.labels_


print(df.head(10))
output_file = 'iris_clusters.xlsx'
df.to_excel(output_file, index=False)

plt.scatter(df['sepal_length'], df['sepal_width'], c=df['cluster'], cmap='viridis')
plt.xlabel('Sepal Length')
plt.ylabel('Sepal Width')
plt.title('K-Means Clustering of Iris Dataset')
plt.show()