# De pe site-ul http://www.crunchbase.com/ , pentru o companie oarecare, extrageti locatia companiei,
# numărul de angajați, website-ul și fondatorii.


import requests, bs4
from bs4 import BeautifulSoup

headers = ({

    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36 Edg/125.0.0.0',

    'From': 'nedelcu1andreea19@stud.ase.ro'

})


URL = "https://www.crunchbase.com/organization/ibm"

def main():
    response = requests.get(URL, headers=headers)
    soup = BeautifulSoup(response.content, 'html.parser')
    #print(soup)
    location = soup.find("span", {"class": "component--field-formatter field-type-identifier-multi"})
    #.find_all("a", {"class": "accent ng-star-inserted"} )
    print(location)
    location_a = location
    finalLoc =""
    for a in location_a:
        finalLoc =finalLoc + " "+a.text
    print("Location:", finalLoc)

    employees =soup.find("a", {"class": "component--field-formatter field-type-enum accent highlight-color-contrast-light ng-star-inserted"})
    print("Employees:", employees.text)

    website = soup.find("a", {"class": "component--field-formatter accent ng-star-inserted"})
    print("Website: ", website.text)

    founders =soup.find("ul", {"class": "text_and_value"}).find_all("a", {"class": "accent ng-star-inserted"})
    start_index = 3
    end_index = 16
    selected_founders = founders[start_index:end_index]
    founders_list = ''
    for i, founder in enumerate(selected_founders, start=start_index):
        founders_list = founders_list + ' ' + founder.text
    print("Founders: ", founders_list)


if __name__ == '__main__':
    main()