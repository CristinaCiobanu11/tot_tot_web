# Se da setul de date: http://archive.ics.uci.edu/ml/datasets/Iris. Sa se utilizeze un
# mecanism de clustering. În ce măsură reflectă rezultatele obținute tipul de plantă?

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

# Încărcați setul de date Iris

column_names = ['sepal_length', 'sepal_width', 'petal_length', 'petal_width', 'class']
iris_data = pd.read_csv("iris.data", names=column_names)

# Selecția caracteristicilor pentru clustering
X = iris_data.drop('class', axis=1)

# Standardizarea datelor
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Aplicarea algoritmului K-Means
kmeans = KMeans(n_clusters=3, random_state=42)
kmeans.fit(X_scaled)

# Afișarea rezultatelor clustering-ului
iris_data['cluster'] = kmeans.labels_
print(iris_data.groupby('cluster')['class'].value_counts())

# Vizualizarea rezultatelor folosind PCA
pca = PCA(n_components=2)
X_pca = pca.fit_transform(X_scaled)
plt.figure(figsize=(8, 6))
plt.scatter(X_pca[:, 0], X_pca[:, 1], c=kmeans.labels_, cmap='viridis')
plt.title('Clustering rezultat folosind PCA')
plt.xlabel('Componenta Principală 1')
plt.ylabel('Componenta Principală 2')
plt.show()

# Evaluarea performanței clustering-ului folosind scorul silhouette
silhouette_avg = silhouette_score(X_scaled, kmeans.labels_)
print("Scorul silhouette pentru clustering-ul K-Means:", silhouette_avg)