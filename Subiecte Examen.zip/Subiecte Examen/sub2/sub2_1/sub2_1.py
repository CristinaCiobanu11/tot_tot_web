# Se da setul de date: http://archive.ics.uci.edu/ml/datasets/Iris. Sa se construiasca
# arborele de clasificare corespunzator. Utilizati primele 90% de inregistrari pentru
# construirea unui arbore de decizie. Se va testa arborele pe inregistrarile 90-100.
import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score

column_names = ['sepal_length', 'sepal_width', 'petal_length', 'petal_width', 'class']
iris_data = pd.read_csv("iris.data", names=column_names)

train_size = int(0.9 * len(iris_data))
train_data = iris_data[:train_size]
#test_data = iris_data[train_size:]
# Extrageți înregistrările de la 90 la 100
test_data = iris_data[90:101]
# Extrageți caracteristicile (atributele) și etichetele (clasele) pentru seturile de antrenare și testare
X_train = train_data.drop('class', axis=1)
y_train = train_data['class']
X_test = test_data.drop('class', axis=1)
y_test = test_data['class']

print(X_test)
# Pasul 5: Antrenați arborele de decizie
clf = DecisionTreeClassifier()
clf.fit(X_train, y_train)

# Pasul 6: Testați arborele de decizie
predictions = clf.predict(X_test)
accuracy = accuracy_score(y_test, predictions)
print("Accuracy:", accuracy)