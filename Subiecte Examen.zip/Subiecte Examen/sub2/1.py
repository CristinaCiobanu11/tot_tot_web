# Se da setul de date:
#
# http://archive.ics.uci.edu/ml/datasets/Iris
#
# Sa se utilizeze un mecanism de clustering. În ce măsură reflectă rezultatele obținute tipul de plantă?

import pandas as pd
from sklearn import preprocessing
from sklearn import tree
from sklearn import metrics
from sklearn import cluster
import numpy as np
import itertools


def print_cluster(clusters, current_id, initial_value, labels = None, n = 0):
    for i in range(n):
        print(' ')
    if current_id < initial_value:
        if labels == None:
            print("      " + current_id)
        else:
            print("      " +labels[0])
    else:
        print('      -')
        current_cluster = [c for c in clusters if current_id == c['id']][0]
        print_cluster(clusters, current_cluster['left'], initial_value, n = n + 1, labels = labels)
        print_cluster(clusters, current_cluster['right'], initial_value, n = n + 1, labels = labels)

#Numele coloanelor preluate din site in ordine
data_columns = ["sepal_length","sepal_width","petal_length","petal_width","class"]
#Citirea datelor
data = pd.read_csv("iris.data",names = data_columns)
#Afisarea primelor 10 randuri din tabela
print("Afisarea primelor 10 randuri din tabela:\n",data.head(10))
print('Numarul de randuri din tabela:\n', {data.shape[0]})

#Amestecarea datelor pentru ca toate sunt in ordine (50 clasa 0, 50 clasa 1, 50 clasa 2)
data = data.sample(frac=1)

#'Encodare' coloanei class
label_encoder = preprocessing.LabelEncoder()
label_encoder.fit(data['class'])

data['class'] = label_encoder.transform(data['class'])

numar_randuri_tabela = data.shape[0]


train = data.iloc[:int(0.9*numar_randuri_tabela),:]
test = data.iloc[int(0.9*numar_randuri_tabela):,:]

print("Afisarea primelor 10 randuri din tabela de antrenament:\n",train.head(5))
print('Numarul de randuri din tabela de antrenament:', {train.shape[0]})

print("Afisarea primelor 10 randuri din tabela de antrenament:\n",test.head(5))
print('Numarul de randuri din tabela de testare:', {test.shape[0]})


train_X = train[["sepal_length","sepal_width","petal_length","petal_width"]]
train_Y = train["class"]

test_X = test[["sepal_length","sepal_width","petal_length","petal_width"]]
test_Y = test["class"]


data = np.array(data)
clusterer = cluster.AgglomerativeClustering(compute_full_tree=True, n_clusters=2, linkage='complete')
model = clusterer.fit(data)

it = itertools.count(data.shape[0])
v = [{'id': next(it), 'left': x[0], 'right':x[1]} for x in model.children_]
# print(numpy_data.shape[)
print_cluster(v, v[-1]['id'], data.shape[0], labels = data_columns)
