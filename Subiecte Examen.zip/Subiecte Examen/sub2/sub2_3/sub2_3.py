# Se dă setul de date: http://archive.ics.uci.edu/ml/datasets/Dresses_Attribute_Sales.
# Să se aplice un algoritm de clustering și să se afișeze care intrare aparține cărui
# cluster.

import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

# Încărcarea setului de date
dresses_data = pd.read_excel("Attribute_DataSet.xlsx")

# Afișarea primelor rânduri ale setului de date pentru a vedea structura acestuia
print(dresses_data.head())

# Renunțăm la coloanele care nu sunt utile pentru clustering (presupunând că primele coloane sunt utile)
# Păstrăm doar coloanele care par să conțină atribute relevante pentru clustering
dresses_data = dresses_data.iloc[:, 1:13]

# Gestionarea valorilor lipsă - înlocuim valorile lipsă cu moda coloanei pentru variabilele categorice și cu media pentru cele numerice
for col in dresses_data.columns:
    if dresses_data[col].dtype == 'object':
        dresses_data[col].fillna(dresses_data[col].mode()[0], inplace=True)
    else:
        dresses_data[col].fillna(dresses_data[col].mean(), inplace=True)

# Utilizarea One-Hot Encoding pentru variabilele categorice
dresses_data_encoded = pd.get_dummies(dresses_data)

# Standardizarea datelor
scaler = StandardScaler()
X_scaled = scaler.fit_transform(dresses_data_encoded)

# Aplicarea algoritmului K-Means
n_clusters = 3  # Puteți ajusta acest număr în funcție de setul de date și de analiza dvs.
kmeans = KMeans(n_clusters=n_clusters, random_state=42)
kmeans.fit(X_scaled)

# Adăugăm rezultatele clustering-ului în setul de date original
dresses_data['cluster'] = kmeans.labels_

# Afișăm primele 10 rânduri pentru a vedea ce intrare aparține cărui cluster
print(dresses_data.head(20))

# Salvează DataFrame-ul în fișierul Excel
dresses_data.to_excel("Data.xlsx", index=False)