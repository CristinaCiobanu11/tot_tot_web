#  Se da setul de date:
# http://archive.ics.uci.edu/ml/machine-learning-databases/mushroom/. Să se
# construiască un mecanism de predicție pentru ciuperci otrăvitoare. Ultimele 10%
# dintre randuri vor fi utilizate ca exemple de test.

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder

# Pasul 1: Încărcarea și explorarea setului de date
url = "http://archive.ics.uci.edu/ml/machine-learning-databases/mushroom/agaricus-lepiota.data"
columns = ['class', 'cap-shape', 'cap-surface', 'cap-color', 'bruises', 'odor', 'gill-attachment',
           'gill-spacing', 'gill-size', 'gill-color', 'stalk-shape', 'stalk-root', 'stalk-surface-above-ring',
           'stalk-surface-below-ring', 'stalk-color-above-ring', 'stalk-color-below-ring', 'veil-type',
           'veil-color', 'ring-number', 'ring-type', 'spore-print-color', 'population', 'habitat']
mushrooms_df = pd.read_csv(url, header=None, names=columns)
print(mushrooms_df)
# Pasul 2: Preprocesarea datelor
# Codificarea caracteristicilor categorice într-o formă numerică
label_encoder = LabelEncoder()
for column in mushrooms_df.columns:
    mushrooms_df[column] = label_encoder.fit_transform(mushrooms_df[column])

# Separarea caracteristicilor și etichetelor
X = mushrooms_df.drop('class', axis=1)
y = mushrooms_df['class']

# Pasul 3: Divizarea setului de date în set de antrenare și set de testare
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)

# Pasul 4: Antrenarea unui model de clasificare
rf_classifier = RandomForestClassifier(random_state=42)
rf_classifier.fit(X_train, y_train)

# Pasul 5: Evaluarea performanței modelului
y_pred = rf_classifier.predict(X_test)

print("-------------------------------")
print(y_pred)
accuracy = accuracy_score(y_test, y_pred)
print("Acuratețea modelului:", accuracy)
print("Raportul de clasificare:")
print(classification_report(y_test, y_pred))
print("Matricea de confuzie:")
print(confusion_matrix(y_test, y_pred))

#Acest lucru înseamnă că modelul dvs. de predicție a clasificat ultimul rând din setul de date de testare drept clasa cu eticheta 1. În contextul problemei de predicție a toxicității ciupercilor, poate însemna că modelul a prezis că ultima ciupercă din setul de date de testare este otrăvitoare (clasa 1). Clasele pot fi etichetate diferit în funcție de cum ați definit problema dvs. de clasificare, dar în acest caz, clasa 1 este asociată cu ciupercile otrăvitoare.

