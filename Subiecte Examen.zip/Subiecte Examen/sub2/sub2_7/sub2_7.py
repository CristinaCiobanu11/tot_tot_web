# Se da setul de date http://archive.ics.uci.edu/ml/datasets/Car+Evaluation. Sa se
# construiasca un mecanism de predictie a pretului (pretul este reprezentat ca o
# categorie). Ultimele 10% dintre randuri vor fi utilizate ca exemple de test.


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# 1. Încărcarea și explorarea datelor
url = "http://archive.ics.uci.edu/ml/machine-learning-databases/car/car.data"
column_names = ["buying", "maint", "doors", "persons", "lug_boot", "safety", "class"]
car_data = pd.read_csv(url, names=column_names)

# Vizualizăm primele câteva rânduri ale datelor
print(car_data.head())

# 2. Pregătirea datelor
# Convertim variabilele categorice în variabile numerice folosind one-hot encoding
car_data = pd.get_dummies(car_data, drop_first=True)

# Definim caracteristicile (X) și variabila de clasă (y)
X = car_data.drop('class_unacc', axis=1)  # Caracteristicile
y = car_data['class_unacc']  # Variabila de clasă

# 3. Divizarea datelor
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)

# 4. Antrenarea modelului
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)

# 5. Evaluarea modelului
y_pred = rf_model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)
