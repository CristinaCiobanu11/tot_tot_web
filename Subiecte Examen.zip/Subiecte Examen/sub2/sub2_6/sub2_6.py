# 7. Se da setul de date: http://archive.ics.uci.edu/ml/datasets/Bank+Marketing#. Sa se
# antreneze un mecanism care sa prezica daca un client va face un depozit pe termen
# lung. Ultimele 10% dintre randuri vor fi utilizate ca exemple de test.


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

# 1. Încărcarea și explorarea datelor
bank_data = pd.read_csv("bank.csv", sep=';')

# Vizualizăm primele câteva rânduri ale datelor
print(bank_data.head())

# 2. Pregătirea datelor
# Convertim variabilele categorice în variabile numerice folosind one-hot encoding
bank_data = pd.get_dummies(bank_data, drop_first=True)

# Definim caracteristicile (X) și variabila de clasă (y)
X = bank_data.drop('y_yes', axis=1)  # Caracteristicile
y = bank_data['y_yes']  # Variabila de clasă

# 3. Divizarea datelor
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.1, random_state=42)

# 4. Antrenarea modelului
rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)

# 5. Evaluarea modelului
y_pred = rf_model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

