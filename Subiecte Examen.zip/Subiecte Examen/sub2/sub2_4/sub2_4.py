# Se da setul de date:
# http://archive.ics.uci.edu/ml/datasets/Congressional+Voting+Records. Sa se clasifice
# printr-un arbore de decizie. Ce informatii suplimentarea capatam alegand metoda
# respectiva? Ultimele 10% dintre randuri vor fi utilizate ca exemple de test

import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, accuracy_score
from sklearn import tree
import matplotlib.pyplot as plt

column_names = ["party", "handicapped-infants", "water-project-cost-sharing", "adoption-of-the-budget-resolution",
                "physician-fee-freeze", "el-salvador-aid", "religious-groups-in-schools", "anti-satellite-test-ban",
                "aid-to-nicaraguan-contras", "mx-missile", "immigration", "synfuels-corporation-cutback",
                "education-spending", "superfund-right-to-sue", "crime", "duty-free-exports", "export-administration-act-south-africa"]
voting_data = pd.read_csv("house-votes-84.data", header=None, names=column_names)



# Înlocuirea valorilor cu 'y' și 'n' cu 1 și 0, iar '?' cu NaN
voting_data.replace({'y': 1, 'n': 0, '?': pd.NA, 'republican': 1, 'democrat': 0}, inplace=True)

print(voting_data)
# Gestionarea valorilor lipsă - înlocuim valorile lipsă cu media coloanei
voting_data.fillna(voting_data.mean(), inplace=True)

# Împărțirea datelor în caracteristici (X) și valori dependente (y)
X = voting_data.drop('party', axis=1)
y = voting_data['party']

# Împărțirea setului de date în date de antrenament și date de test
split_index = int(len(X) * 0.9)
X_train, X_test = X[:split_index], X[split_index:]
y_train, y_test = y[:split_index], y[split_index:]

# Construirea și antrenarea unui arbore de decizie
classifier = DecisionTreeClassifier(random_state=42)
classifier.fit(X_train, y_train)

# Testarea modelului pe datele de test
y_pred = classifier.predict(X_test)

# Evaluarea performanței
print("Accuracy:", accuracy_score(y_test, y_pred))
print(classification_report(y_test, y_pred))

# Vizualizarea arborelui de decizie
plt.figure(figsize=(20,10))
tree.plot_tree(classifier, feature_names=X.columns, class_names=['republican', 'democrat'], filled=True)
plt.show()

# Afișarea importanței caracteristicilor
feature_importances = pd.Series(classifier.feature_importances_, index=X.columns).sort_values(ascending=False)
print("Importanța caracteristicilor:")
print(feature_importances)