#  Se da setul de date:
# http://archive.ics.uci.edu/ml/datasets/Syskill+and+Webert+Web+Page+Ratings. Sa
# se construiasca un mecanism de predictie a ratingului (ratingul este reprezentat ca o
# categorie). Ultimele 10% dintre randuri vor fi utilizate ca exemple de test.


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score

from bs4 import BeautifulSoup

# Citim fișierele HTML și parsăm datele folosind BeautifulSoup
with open("SyskillWebert.html", "r") as f:
    html_content = f.read()

soup = BeautifulSoup(html_content, "html.parser")

# Extragem datele din fișierele HTML și le transformăm într-un DataFrame
# În funcție de structura fișierelor HTML, va trebui să adaptezi acest cod pentru a potrivi cu datele exacte

# Exemplu de cod pentru a extrage datele dintr-un tabel HTML și a le transforma într-un DataFrame
table = soup.find("table")
df = pd.read_html(str(table))[0]

print(df)



# Descărcarea și încărcarea setului de date

data = pd.read_csv("SyskillWebert.data.html")

print(data)
# Preprocesarea datelor
# De exemplu, putem elimina coloanele nedorite și trata valorile lipsă

# Separarea datelor în seturi de antrenare și testare
train_data, test_data = train_test_split(data, test_size=0.1, random_state=42)

# Definirea caracteristicilor și a etichetelor
X_train = train_data.drop("Rating", axis=1)
y_train = train_data["Rating"]
X_test = test_data.drop("Rating", axis=1)
y_test = test_data["Rating"]

# Antrenarea modelului Random Forest
model = RandomForestClassifier(random_state=42)
model.fit(X_train, y_train)

# Evaluarea performanței modelului
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)
print("Accuracy:", accuracy)

# Predicția ratingului pentru datele de testare
# De exemplu, putem vedea predicția pentru ultimul rând din setul de date de testare
last_row = X_test.tail(1)
prediction = model.predict(last_row)
print("Predicția pentru ultimul rând:", prediction)
